const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BYJOqshj.js","./BO3dwi8K.js","./DAEHUenk.js","./UKKIIVS_.js","./DML5ZlwR.js"])))=>i.map(i=>d[i]);
import{r as t,t as n,Y as s,Z as r}from"./UKKIIVS_.js";function m(){const e=t(!1),o=n(()=>s(()=>r(()=>import("./BYJOqshj.js"),__vite__mapDeps([0,1,2,3,4]),import.meta.url)));return{showComponentName:e,devLinksComponent:o}}export{m as default,m as useDevLinks};
//# sourceMappingURL=BctQNz0x.js.map
