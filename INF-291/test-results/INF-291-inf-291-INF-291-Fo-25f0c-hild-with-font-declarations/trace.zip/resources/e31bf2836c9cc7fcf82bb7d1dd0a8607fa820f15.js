import{K as a,e as s,L as r,M as u,N as o}from"./UKKIIVS_.js";function i(t){const n=t||s();return n.ssrContext?.head||n.runWithContext(()=>{if(r()){const e=u(o);if(!e)throw new Error("[nuxt] [unhead] Missing Unhead instance.");return e}})}function d(t,n={}){const e=i(n.nuxt);return a(t,{head:e,...n})}export{d as u};
//# sourceMappingURL=DzPVuLJe.js.map
