import{_ as t,D as s,E as n,S as a,P as o,U as c}from"./UKKIIVS_.js";const l=["innerHTML"],r={__name:"CanvasAemTagCloud",props:{tagCloud:{type:String,default:""}},setup(e){return(_,u)=>(n(),s("div",{class:"tag-cont",innerHTML:a(o)(e.tagCloud,a(c))},null,8,l))}},i=t(r,[["__scopeId","data-v-2f139ebf"]]);export{i as default};
//# sourceMappingURL=gm5f_TYb.js.map
