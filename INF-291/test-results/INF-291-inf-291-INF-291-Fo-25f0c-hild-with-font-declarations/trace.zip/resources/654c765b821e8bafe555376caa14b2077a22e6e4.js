import{Z as n}from"./UKKIIVS_.js";const o=new Promise((e,r)=>"IntersectionObserver"in window?e(window.IntersectionObserver):n(()=>import("./UKKIIVS_.js").then(t=>t.bt),[],import.meta.url).then(()=>e(window.IntersectionObserver)).catch(r));export{o as default};
//# sourceMappingURL=CzKdI3oi.js.map
